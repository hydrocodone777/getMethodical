//import java.util.Scanner;
//public class DevTest {
//    public static Scanner testScan = new Scanner(System.in);
//
//    public static void main(String[] args) {
//        String firstname = "";
//        firstname = SafeInput.getNonZeroLenString(testScan, "Enter your first name");
//        System.out.println("First name is " + firstname);
//        int age = 0;
//        int low = 1;
//        int high = 10;
//        String ssn = "";
//        age = SafeInput.getRangeInt(testScan, "Enter your age");
//        System.out.println("You said your age is: " + age);
//        String ssnRegEx = "\\d{3}-\\d{2}-\\d{4}$";
//        ssn = SafeInput.getRegExString(testScan, "Enter your ssn",ssnRegEx);
//        System.out.println();
//    }
//}








