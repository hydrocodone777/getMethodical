import java.util.Scanner;

public class PrettyHeader {
    public static void main(String[] args) {

    }
    public static void String pattern(Scanner pipe, String prompt){
        for(int c = 1; c <= 60; c++){
            System.out.print("*");}
        System.out.println();
    }
}
