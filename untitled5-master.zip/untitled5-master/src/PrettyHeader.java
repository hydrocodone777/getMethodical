import java.util.Scanner;

public class PrettyHeader {
    public static void main(String[] args) {
        Scanner testScan = new Scanner(System.in);
        String header = "";
        header = pattern(testScan, "Enter title");
    }

    public static String pattern(Scanner pipe, String prompt) {
        for (int c = 1; c <= 60; c++) {
            System.out.print("*");
        }
        System.out.println();
        String text = pipe.nextLine();
        int stringSize = text.length();
        int center = (54 - stringSize) / 2;
        for (int c = 1; c <= 3; c++) {
            System.out.print("*");
            for (c = 4; c <= 4 + center; c++) {
                System.out.print(" ");
            }
            System.out.print(text);
        }
        return(text);
    }
}